;<?php return; ?>
[SQL]
host = localhost
user = root
password = Black2berry
dbname = lifepith
