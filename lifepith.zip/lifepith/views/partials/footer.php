</div>
</div>
</div>
</div>
</article>
</main>
</div>
</div>
</div>
<footer class="ast-site-footer site-footer" id="colophon" itemtype="https://schema.org/WPFooter" itemscope="itemscope" itemid="#colophon">
    <div class="ast-main-footer-wrap">
        <div class="site-above-footer-wrap ast-builder-grid-row-container site-footer-focus-item ast-builder-grid-row-3-equal ast-builder-grid-row-tablet-3-equal ast-builder-grid-row-mobile-full ast-footer-row-stack ast-footer-row-tablet-stack ast-footer-row-mobile-stack" data-section="section-above-footer-builder">
            <div class="ast-builder-grid-row-container-inner">
                <div class="ast-builder-footer-grid-columns site-above-footer-inner-wrap ast-builder-grid-row">
                    <div class="site-footer-above-section-1 site-footer-section site-footer-section-1">
                        <aside class="footer-widget-area widget-area site-footer-focus-item" data-section="sidebar-widgets-footer-widget-1">
                            <div class="footer-widget-area-inner site-info-inner">
                                <section id="media_image-3" class="widget widget_media_image" style="margin:0;"><img width="100" height="150" src="<?= config::logo_white() ?>" class="image attachment-thumbnail size-thumbnail" alt="Logo Regular" loading="lazy" style="max-width: 100%; height: auto;" srcset="<?= config::logo_white() ?> 1x, <?= config::logo_white() ?> 2x" /></section>
                                <section id="text-3" class="widget widget_text">
                                    <div class="textwidget">
                                        <p>
                                    </div>
                                </section>
                                <section id="text-4" class="widget widget_text">
                                    <h2 class="widget-title">Follow Us</h2>
                                    <div class="textwidget"></div>
                                </section>
                            </div>
                        </aside>
                        <div class="ast-builder-layout-element ast-flex site-footer-focus-item" data-section="section-fb-social-icons-1">
                            <div class="ast-footer-social-1-wrap ast-footer-social-wrap">
                                <div class="footer-social-inner-wrap element-social-inner-wrap social-show-label-false ast-social-color-type-custom ast-social-element-style-filled">
                                    <a href="<?= config::facebook(); ?>" target="_blank" rel="noopener noreferrer" style="--color: #557dbc; --background-color: transparent;" class="ast-builder-social-element ast-inline-flex ast-facebook footer-social-item">
                                        <span class="ahfb-svg-iconset ast-inline-flex svg-baseline">
                                            <svg aria-labelledby='facebook' xmlns='http://www.w3.org/2000/svg' width='24' height='28' viewBox='0 0 24 28'>
                                                <title>Facebook</title>
                                                <path d='M19.5 2C21.984 2 24 4.016 24 6.5v15c0 2.484-2.016 4.5-4.5 4.5h-2.938v-9.297h3.109l.469-3.625h-3.578v-2.312c0-1.047.281-1.75 1.797-1.75L20.265 9V5.766c-.328-.047-1.469-.141-2.781-.141-2.766 0-4.672 1.687-4.672 4.781v2.672H9.687v3.625h3.125V26H4.499a4.502 4.502 0 01-4.5-4.5v-15c0-2.484 2.016-4.5 4.5-4.5h15z'></path>
                                            </svg>
                                        </span>
                                    </a>
                                    <a href="<?= config::linkedin(); ?>" target="_blank" rel="noopener noreferrer" style="--color: #7acdee; --background-color: transparent;" class="ast-builder-social-element ast-inline-flex ast-twitter footer-social-item">
                                        <span class="ahfb-svg-iconset ast-inline-flex svg-baseline">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" aria-labelledby="title" aria-describedby="desc" role="img" xmlns:xlink="http://www.w3.org/1999/xlink">
                                                <title>Linkedin</title>
                                                <path data-name="layer1" fill="#0077b7" d="M1.15 21.7h13V61h-13zm46.55-1.3c-5.7 0-9.1 2.1-12.7 6.7v-5.4H22V61h13.1V39.7c0-4.5 2.3-8.9 7.5-8.9s8.3 4.4 8.3 8.8V61H64V38.7c0-15.5-10.5-18.3-16.3-18.3zM7.7 2.6C3.4 2.6 0 5.7 0 9.5s3.4 6.9 7.7 6.9 7.7-3.1 7.7-6.9S12 2.6 7.7 2.6z"></path>
                                            </svg>
                                        </span>
                                    </a>
                                    <a href="<?= config::instagram(); ?>" target="_blank" rel="noopener noreferrer" style="--color: #8a3ab9; --background-color: transparent;" class="ast-builder-social-element ast-inline-flex ast-instagram footer-social-item">
                                        <span class="ahfb-svg-iconset ast-inline-flex svg-baseline">
                                            <svg aria-labelledby='instagram' xmlns='http://www.w3.org/2000/svg' width='32' height='32' viewBox='0 0 32 32'>
                                                <title>Instagram</title>
                                                <path d='M21.138.242c3.767.007 3.914.038 4.65.144 1.52.219 2.795.825 3.837 1.821a6.243 6.243 0 011.349 1.848c.442.899.659 1.75.758 3.016.021.271.031 4.592.031 8.916s-.009 8.652-.03 8.924c-.098 1.245-.315 2.104-.743 2.986a6.6 6.6 0 01-4.303 3.522c-.685.177-1.304.26-2.371.31-.381.019-4.361.024-8.342.024s-7.959-.012-8.349-.029c-.921-.044-1.639-.136-2.288-.303a6.64 6.64 0 01-4.303-3.515c-.436-.904-.642-1.731-.751-3.045-.031-.373-.039-2.296-.039-8.87 0-2.215-.002-3.866 0-5.121.006-3.764.037-3.915.144-4.652.219-1.518.825-2.795 1.825-3.833a6.302 6.302 0 011.811-1.326C4.939.603 5.78.391 7.13.278 7.504.247 9.428.24 16.008.24h5.13zm-5.139 4.122c-3.159 0-3.555.014-4.796.07-1.239.057-2.084.253-2.824.541-.765.297-1.415.695-2.061 1.342S5.273 7.613 4.975 8.378c-.288.74-.485 1.586-.541 2.824-.056 1.241-.07 1.638-.07 4.798s.014 3.556.07 4.797c.057 1.239.253 2.084.541 2.824.297.765.695 1.415 1.342 2.061s1.296 1.046 2.061 1.343c.74.288 1.586.484 2.825.541 1.241.056 1.638.07 4.798.07s3.556-.014 4.797-.07c1.239-.057 2.085-.253 2.826-.541.765-.297 1.413-.696 2.06-1.343s1.045-1.296 1.343-2.061c.286-.74.482-1.586.541-2.824.056-1.241.07-1.637.07-4.797s-.015-3.557-.07-4.798c-.058-1.239-.255-2.084-.541-2.824-.298-.765-.696-1.415-1.343-2.061s-1.295-1.045-2.061-1.342c-.742-.288-1.588-.484-2.827-.541-1.241-.056-1.636-.07-4.796-.07zm-1.042 2.097h1.044c3.107 0 3.475.011 4.702.067 1.135.052 1.75.241 2.16.401.543.211.93.463 1.337.87s.659.795.871 1.338c.159.41.349 1.025.401 2.16.056 1.227.068 1.595.068 4.701s-.012 3.474-.068 4.701c-.052 1.135-.241 1.75-.401 2.16-.211.543-.463.93-.871 1.337s-.794.659-1.337.87c-.41.16-1.026.349-2.16.401-1.227.056-1.595.068-4.702.068s-3.475-.012-4.702-.068c-1.135-.052-1.75-.242-2.161-.401-.543-.211-.931-.463-1.338-.87s-.659-.794-.871-1.337c-.159-.41-.349-1.025-.401-2.16-.056-1.227-.067-1.595-.067-4.703s.011-3.474.067-4.701c.052-1.135.241-1.75.401-2.16.211-.543.463-.931.871-1.338s.795-.659 1.338-.871c.41-.16 1.026-.349 2.161-.401 1.073-.048 1.489-.063 3.658-.065v.003zm1.044 3.563a5.977 5.977 0 10.001 11.953 5.977 5.977 0 00-.001-11.953zm0 2.097a3.879 3.879 0 110 7.758 3.879 3.879 0 010-7.758zm6.211-3.728a1.396 1.396 0 100 2.792 1.396 1.396 0 000-2.792v.001z'></path>
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="site-footer-above-section-2 site-footer-section site-footer-section-2">
                        <aside class="footer-widget-area widget-area site-footer-focus-item" data-section="sidebar-widgets-footer-widget-2">
                            <div class="footer-widget-area-inner site-info-inner">
                                <section id="text-5" class="widget widget_text">
                                    <h2 class="widget-title"></h2>
                                    <div class="textwidget white-link">
                                        <p><a href="about">Who we are</a></p>
                                        <hr />
                                        <p><a href="theory">Our Theory of change</a></p>
                                        <hr />
                                        <p><a href="blog">Blog</a></p>
                                        <hr />
                                        <p><a href="contact">Contact Us</a></p>
                                        <hr />
                                    </div>
                                </section>
                            </div>
                        </aside>
                    </div>
                    <div class="site-footer-above-section-3 site-footer-section site-footer-section-3">
                        <aside class="footer-widget-area widget-area site-footer-focus-item" data-section="sidebar-widgets-footer-widget-3">
                            <div class="footer-widget-area-inner site-info-inner">
                                <section id="text-6" class="widget widget_text">
                                    <h2 class="widget-title">Want to share in our journey?</h2>
                                    <h3 class="subscribe-h3">Subscribe to our newsletter!</h3>
                                    <div class="textwidget"></div>
                                </section>
                                <section id="wpforms-widget-3" class="widget wpforms-widget">
                                    <div class="wpforms-container " id="wpforms-74">
                                        <form id="wpforms-form-74" class="wpforms-validate wpforms-form" data-formid="74" method="post" enctype="multipart/form-data" action="index.html" data-token="1f1bd9b95570cf8a2590d7ac3d03d7df"><noscript class="wpforms-error-noscript">Please enable JavaScript in your browser to complete this form.</noscript>
                                            <div class="wpforms-field-container">
                                                <div id="wpforms-74-field_1-container" class="wpforms-field wpforms-field-email" data-field-id="1"><input type="email" id="wpforms-74-field_1" class="wpforms-field-large" name="wpforms[fields][1]" placeholder="Enter your email..."></div>
                                            </div>
                                            <div class="wpforms-field wpforms-field-hp"><label for="wpforms-74-field-hp" class="wpforms-field-label">Phone</label><input type="text" name="wpforms[hp]" id="wpforms-74-field-hp" class="wpforms-field-medium"></div>
                                            <div class="wpforms-submit-container"><input type="hidden" name="wpforms[id]" value="74"><input type="hidden" name="wpforms[author]" value="20"><input type="hidden" name="wpforms[post_id]" value="6"><button type="submit" name="wpforms[submit]" class="wpforms-submit btn-dark" id="wpforms-submit-74" value="wpforms-submit" aria-live="assertive" data-alt-text="Sending..." data-submit-text="Subscribe">Subscribe</button></div>
                                        </form>
                                    </div>
                                </section>
                            </div>
                        </aside>
                    </div>
                </div>
            </div>
        </div>
        <div class="site-below-footer-wrap ast-builder-grid-row-container site-footer-focus-item ast-builder-grid-row-2-equal ast-builder-grid-row-tablet-2-equal ast-builder-grid-row-mobile-full ast-footer-row-stack ast-footer-row-tablet-stack ast-footer-row-mobile-stack" data-section="section-below-footer-builder">
            <div class="ast-builder-grid-row-container-inner">
                <div class="ast-builder-footer-grid-columns site-below-footer-inner-wrap ast-builder-grid-row">
                    <div class="site-footer-below-section-1 site-footer-section site-footer-section-1">
                        <div class="ast-builder-layout-element ast-flex site-footer-focus-item ast-footer-copyright" data-section="section-footer-builder">
                            <div class="ast-footer-copyright">
                                <div class="ast-footer-html-inner">
                                    <p>Copyright © <?= date("Y") ?> <?= config::name() ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="site-footer-below-section-2 site-footer-section site-footer-section-2">
                        <div class="footer-widget-area widget-area site-footer-focus-item ast-footer-html-2" data-section="section-fb-html-2">
                            <div class="ast-header-html inner-link-style-">
                                <div class="ast-builder-html-element">
                                    <p>Developed by
                                        <a href="https://kennethekandem.netlify.app" target="_blank" style="color: #fff;">Kenneth Ekandem</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
</div>
<link rel='stylesheet' id='wpforms-base-css' href='assets/plugins/wpforms-lite/assets/css/wpforms-base.min-ver=1.6.5.css' media='all' />
<script id='astra-theme-js-js-extra'>
    var astra = {
        "break_point": "921",
        "isRtl": ""
    };
</script>
<script src='assets/js/minified/frontend.min-ver=3.0.3.js' id='astra-theme-js-js'></script>
<script src='wp-includes/js/wp-embed.min-ver=5.6.2.js' id='wp-embed-js'></script>
<script src='assets/plugins/elementor/assets/js/webpack.runtime.min-ver=3.1.2.js' id='elementor-webpack-runtime-js'></script>
<script src='wp-includes/js/jquery/jquery.min-ver=3.5.1.js' id='jquery-core-js'></script>
<script src='wp-includes/js/jquery/jquery-migrate.min-ver=3.3.2.js' id='jquery-migrate-js'></script>
<script src='assets/plugins/elementor/assets/js/frontend-modules.min-ver=3.1.2.js' id='elementor-frontend-modules-js'></script>
<script src='wp-includes/js/jquery/ui/core.min-ver=1.12.1.js' id='jquery-ui-core-js'></script>
<script src='assets/plugins/elementor/assets/lib/dialog/dialog.min-ver=4.8.1.js' id='elementor-dialog-js'></script>
<script src='assets/plugins/elementor/assets/lib/waypoints/waypoints.min-ver=4.0.2.js' id='elementor-waypoints-js'></script>
<script src='assets/plugins/elementor/assets/lib/share-link/share-link.min-ver=3.1.2.js' id='share-link-js'></script>
<script src='assets/plugins/elementor/assets/lib/swiper/swiper.min-ver=5.3.6.js' id='swiper-js'></script>
<script id='elementor-frontend-js-before'>
    var elementorFrontendConfig = {
        "environmentMode": {
            "edit": false,
            "wpPreview": false,
            "isScriptDebug": false,
            "isImprovedAssetsLoading": false
        },
        "i18n": {
            "shareOnFacebook": "Share on Facebook",
            "shareOnTwitter": "Share on Twitter",
            "pinIt": "Pin it",
            "download": "Download",
            "downloadImage": "Download image",
            "fullscreen": "Fullscreen",
            "zoom": "Zoom",
            "share": "Share",
            "playVideo": "Play Video",
            "previous": "Previous",
            "next": "Next",
            "close": "Close"
        },
        "is_rtl": false,
        "breakpoints": {
            "xs": 0,
            "sm": 480,
            "md": 768,
            "lg": 1025,
            "xl": 1440,
            "xxl": 1600
        },
        "version": "3.1.2",
        "is_static": false,
        "experimentalFeatures": [],
        "urls": {
            "assets": "https:\/\/websitedemos.net\/women-empowerment-02\/wp-content\/plugins\/elementor\/assets\/"
        },
        "settings": {
            "page": [],
            "editorPreferences": []
        },
        "kit": {
            "global_image_lightbox": "yes",
            "lightbox_enable_counter": "yes",
            "lightbox_enable_fullscreen": "yes",
            "lightbox_enable_zoom": "yes",
            "lightbox_enable_share": "yes",
            "lightbox_title_src": "title",
            "lightbox_description_src": "description"
        },
        "post": {
            "id": 6,
            "title": "Women%20Empowerment%20NGO%20%E2%80%93%20Women%20Empowerment%20NGO%20Website",
            "excerpt": "",
            "featuredImage": false
        }
    };
</script>
<script src='assets/plugins/elementor/assets/js/frontend.min-ver=3.1.2.js' id='elementor-frontend-js'></script>
<script src='assets/plugins/elementor/assets/js/preloaded-elements-handlers.min-ver=3.1.2.js' id='preloaded-elements-handlers-js'></script>
<script src='wp-includes/js/underscore.min-ver=1.8.3.js' id='underscore-js'></script>
<script id='wp-util-js-extra'>
    var _wpUtilSettings = {
        "ajax": {
            "url": "\/women-empowerment-02\/wp-admin\/admin-ajax.php"
        }
    };
</script>
<script src='wp-includes/js/wp-util.min-ver=5.6.2.js' id='wp-util-js'></script>
<script id='wpforms-elementor-js-extra'>
    var wpformsElementorVars = {
        "captcha_provider": "recaptcha",
        "recaptcha_type": "v2"
    };
</script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
<script src='assets/plugins/wpforms-lite/assets/js/integrations/elementor/frontend.min-ver=1.6.5.js' id='wpforms-elementor-js'></script>
<script src='assets/plugins/wpforms-lite/assets/js/jquery.validate.min-ver=1.19.0.js' id='wpforms-validation-js'></script>
<script src='assets/plugins/wpforms-lite/assets/js/mailcheck.min-ver=1.1.2.js' id='wpforms-mailcheck-js'></script>
<script src='assets/plugins/wpforms-lite/assets/js/wpforms-ver=1.6.5.js' id='wpforms-js'></script>
<script>
    /(trident|msie)/i.test(navigator.userAgent) && document.getElementById && window.addEventListener && window.addEventListener("hashchange", function() {
        var t, e = location.hash.substring(1);
        /^[A-z0-9_-]+$/.test(e) && (t = document.getElementById(e)) && (/^(?:a|select|input|button|textarea)$/i.test(t.tagName) || (t.tabIndex = -1), t.focus())
    }, !1);
</script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var wpforms_settings = {
        "val_required": "This field is required.",
        "val_url": "Please enter a valid URL.",
        "val_email": "Please enter a valid email address.",
        "val_email_suggestion": "Did you mean {suggestion}?",
        "val_email_suggestion_title": "Click to accept this suggestion.",
        "val_email_restricted": "This email address is not allowed.",
        "val_number": "Please enter a valid number.",
        "val_number_positive": "Please enter a valid positive number.",
        "val_confirm": "Field values do not match.",
        "val_fileextension": "File type is not allowed.",
        "val_filesize": "File exceeds max size allowed. File was not uploaded.",
        "val_time12h": "Please enter time in 12-hour AM\/PM format (eg 8:45 AM).",
        "val_time24h": "Please enter time in 24-hour format (eg 22:45).",
        "val_requiredpayment": "Payment is required.",
        "val_creditcard": "Please enter a valid credit card number.",
        "val_post_max_size": "The total size of the selected files {totalSize} Mb exceeds the allowed limit {maxSize} Mb.",
        "val_checklimit": "You have exceeded the number of allowed selections: {#}.",
        "val_limit_characters": "{count} of {limit} max characters.",
        "val_limit_words": "{count} of {limit} max words.",
        "val_recaptcha_fail_msg": "Google reCAPTCHA verification failed, please try again later.",
        "val_empty_blanks": "Please fill out all blanks.",
        "post_max_size": "268435456",
        "uuid_cookie": "",
        "locale": "en",
        "wpforms_plugin_url": "https:\/\/websitedemos.net\/women-empowerment-02\/wp-content\/plugins\/wpforms-lite\/",
        "gdpr": "",
        "ajaxurl": "https:\/\/websitedemos.net\/women-empowerment-02\/wp-admin\/admin-ajax.php",
        "mailcheck_enabled": "1",
        "mailcheck_domains": [],
        "mailcheck_toplevel_domains": ["dev"],
        "is_ssl": "1"
    }
    /* ]]> */
</script>

<script>
    /**
     *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
     *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables    */
    /*
    var disqus_config = function () {
    this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
    this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
    };
    */
    (function() { // DON'T EDIT BELOW THIS LINE
        var d = document,
            s = d.createElement('script');
        s.src = 'https://lifepith.disqus.com/embed.js';
        s.setAttribute('data-timestamp', +new Date());
        (d.head || d.body).appendChild(s);
    })();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>

<script id="mcjs">
    ! function(c, h, i, m, p) {
        m = c.createElement(h), p = c.getElementsByTagName(h)[0], m.async = 1, m.src = i, p.parentNode.insertBefore(m, p)
    }(document, "script", "https://chimpstatic.com/mcjs-connected/js/users/924180068373cb80693f1dc31/61200fbe9529eea055b088ce6.js");
</script>
</body>

</html>