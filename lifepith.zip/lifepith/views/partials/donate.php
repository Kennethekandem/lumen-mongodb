<section class="elementor-section elementor-top-section elementor-element elementor-element-62525519 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="62525519" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
    <div class="elementor-background-overlay"></div>
    <div class="elementor-container elementor-column-gap-no">
        <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2e95d168" data-id="2e95d168" data-element_type="column">
                <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                        <div class="elementor-element elementor-element-46f8b25 elementor-widget elementor-widget-heading" data-id="46f8b25" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container">
                                <h6 class="elementor-heading-title elementor-size-default">Want to make a difference?</h6>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-2b059517 elementor-widget elementor-widget-heading" data-id="2b059517" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container">
                                <h2 class="elementor-heading-title elementor-size-default">Help us with money to reach more young leaders</h2>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-b5be7a1 elementor-align-center elementor-widget elementor-widget-button" data-id="b5be7a1" data-element_type="widget" data-widget_type="button.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-button-wrapper">
                                    <a href="#" class="elementor-button-link elementor-button elementor-size-sm" role="button">
                                                            <span class="elementor-button-content-wrapper">
                                                                <span class="elementor-button-text">Donate</span>
                                                            </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>