<div class="elementor-container elementor-column-gap-no">
    <div class="elementor-row tab-content" id="pills-tabContent">
        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-6f8dbf1" data-id="6f8dbf1" data-element_type="column">
            <div class="elementor-column-wrap elementor-element-populated">
                <div class="elementor-widget-wrap">
                    <div class="elementor-element elementor-element-9b646f0 elementor-widget elementor-widget-heading" data-id="9b646f0" data-element_type="widget" data-widget_type="heading.default">
                        <div class="elementor-widget-container">
                            <h6 class="elementor-heading-title elementor-size-default">17 July, 2020</h6> </div>
                    </div>
                    <div class="elementor-element elementor-element-919b06c elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="919b06c" data-element_type="widget" data-widget_type="divider.default">
                        <div class="elementor-widget-container">
                            <div class="elementor-divider">
<span class="elementor-divider-separator">
</span>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-element elementor-element-18ccba2 elementor-widget elementor-widget-heading" data-id="18ccba2" data-element_type="widget" data-widget_type="heading.default">
                        <div class="elementor-widget-container">
                            <h4 class="elementor-heading-title elementor-size-default"><a href="index.html#">Education Programmes that lorem ipsum</a></h4> </div>
                    </div>
                    <div class="elementor-element elementor-element-7b8dc5e elementor-widget elementor-widget-text-editor" data-id="7b8dc5e" data-element_type="widget" data-widget_type="text-editor.default">
                        <div class="elementor-widget-container">
                            <div class="elementor-text-editor elementor-clearfix">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis nec a odio.</div>
                        </div>
                    </div>
                    <div class="elementor-element elementor-element-79cfc23 elementor-align-justify elementor-widget elementor-widget-button" data-id="79cfc23" data-element_type="widget" data-widget_type="button.default">
                        <div class="elementor-widget-container">
                            <div class="elementor-button-wrapper">
                                <a href="index.html#" class="elementor-button-link elementor-button elementor-size-sm" role="button">
                                                                                    <span class="elementor-button-content-wrapper">
                                                                                        <span class="elementor-button-text">Read more</span>
                                                                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-6f8dbf1" data-id="6f8dbf1" data-element_type="column" role="tabpanel" aria-labelledby="pills-Faith-tab" id="pills-Faith">
            <div class="elementor-column-wrap elementor-element-populated">
                <div class="elementor-widget-wrap">
                    <div class="elementor-element elementor-element-9b646f0 elementor-widget elementor-widget-heading" data-id="9b646f0" data-element_type="widget" data-widget_type="heading.default">
                        <div class="elementor-widget-container">
                            <h6 class="elementor-heading-title elementor-size-default">17 July, 2020</h6> </div>
                    </div>
                    <div class="elementor-element elementor-element-919b06c elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="919b06c" data-element_type="widget" data-widget_type="divider.default">
                        <div class="elementor-widget-container">
                            <div class="elementor-divider">
<span class="elementor-divider-separator">
</span>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-element elementor-element-18ccba2 elementor-widget elementor-widget-heading" data-id="18ccba2" data-element_type="widget" data-widget_type="heading.default">
                        <div class="elementor-widget-container">
                            <h4 class="elementor-heading-title elementor-size-default"><a href="index.html#">Education Programmes that lorem ipsum</a></h4> </div>
                    </div>
                    <div class="elementor-element elementor-element-7b8dc5e elementor-widget elementor-widget-text-editor" data-id="7b8dc5e" data-element_type="widget" data-widget_type="text-editor.default">
                        <div class="elementor-widget-container">
                            <div class="elementor-text-editor elementor-clearfix">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis nec a odio.</div>
                        </div>
                    </div>
                    <div class="elementor-element elementor-element-79cfc23 elementor-align-justify elementor-widget elementor-widget-button" data-id="79cfc23" data-element_type="widget" data-widget_type="button.default">
                        <div class="elementor-widget-container">
                            <div class="elementor-button-wrapper">
                                <a href="index.html#" class="elementor-button-link elementor-button elementor-size-sm" role="button">
<span class="elementor-button-content-wrapper">
<span class="elementor-button-text">Read more</span>
</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-6f8dbf1" data-id="6f8dbf1" data-element_type="column" role="tabpanel" aria-labelledby="pills-Lifestyle-tab" id="pills-Lifestyle">
            <div class="elementor-column-wrap elementor-element-populated">
                <div class="elementor-widget-wrap">
                    <div class="elementor-element elementor-element-9b646f0 elementor-widget elementor-widget-heading" data-id="9b646f0" data-element_type="widget" data-widget_type="heading.default">
                        <div class="elementor-widget-container">
                            <h6 class="elementor-heading-title elementor-size-default">17 July, 2020</h6> </div>
                    </div>
                    <div class="elementor-element elementor-element-919b06c elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="919b06c" data-element_type="widget" data-widget_type="divider.default">
                        <div class="elementor-widget-container">
                            <div class="elementor-divider">
<span class="elementor-divider-separator">
</span>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-element elementor-element-18ccba2 elementor-widget elementor-widget-heading" data-id="18ccba2" data-element_type="widget" data-widget_type="heading.default">
                        <div class="elementor-widget-container">
                            <h4 class="elementor-heading-title elementor-size-default"><a href="index.html#">Education Programmes that lorem ipsum</a></h4> </div>
                    </div>
                    <div class="elementor-element elementor-element-7b8dc5e elementor-widget elementor-widget-text-editor" data-id="7b8dc5e" data-element_type="widget" data-widget_type="text-editor.default">
                        <div class="elementor-widget-container">
                            <div class="elementor-text-editor elementor-clearfix">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis nec a odio.</div>
                        </div>
                    </div>
                    <div class="elementor-element elementor-element-79cfc23 elementor-align-justify elementor-widget elementor-widget-button" data-id="79cfc23" data-element_type="widget" data-widget_type="button.default">
                        <div class="elementor-widget-container">
                            <div class="elementor-button-wrapper">
                                <a href="index.html#" class="elementor-button-link elementor-button elementor-size-sm" role="button">
<span class="elementor-button-content-wrapper">
<span class="elementor-button-text">Read more</span>
</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-6f8dbf1" data-id="6f8dbf1" data-element_type="column" role="tabpanel" aria-labelledby="pills-Health-tab" id="pills-Health">
            <div class="elementor-column-wrap elementor-element-populated">
                <div class="elementor-widget-wrap">
                    <div class="elementor-element elementor-element-9b646f0 elementor-widget elementor-widget-heading" data-id="9b646f0" data-element_type="widget" data-widget_type="heading.default">
                        <div class="elementor-widget-container">
                            <h6 class="elementor-heading-title elementor-size-default">17 July, 2020</h6> </div>
                    </div>
                    <div class="elementor-element elementor-element-919b06c elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="919b06c" data-element_type="widget" data-widget_type="divider.default">
                        <div class="elementor-widget-container">
                            <div class="elementor-divider">
<span class="elementor-divider-separator">
</span>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-element elementor-element-18ccba2 elementor-widget elementor-widget-heading" data-id="18ccba2" data-element_type="widget" data-widget_type="heading.default">
                        <div class="elementor-widget-container">
                            <h4 class="elementor-heading-title elementor-size-default"><a href="index.html#">Education Programmes that lorem ipsum</a></h4> </div>
                    </div>
                    <div class="elementor-element elementor-element-7b8dc5e elementor-widget elementor-widget-text-editor" data-id="7b8dc5e" data-element_type="widget" data-widget_type="text-editor.default">
                        <div class="elementor-widget-container">
                            <div class="elementor-text-editor elementor-clearfix">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis nec a odio.</div>
                        </div>
                    </div>
                    <div class="elementor-element elementor-element-79cfc23 elementor-align-justify elementor-widget elementor-widget-button" data-id="79cfc23" data-element_type="widget" data-widget_type="button.default">
                        <div class="elementor-widget-container">
                            <div class="elementor-button-wrapper">
                                <a href="index.html#" class="elementor-button-link elementor-button elementor-size-sm" role="button">
<span class="elementor-button-content-wrapper">
<span class="elementor-button-text">Read more</span>
</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>