<?php

unset($_SESSION['logged_admin']);
header("location:logout");