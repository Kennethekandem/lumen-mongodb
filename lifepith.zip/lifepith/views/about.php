<article class="post-8 page type-page status-publish ast-article-single" id="post-8" itemtype="https://schema.org/CreativeWork" itemscope="itemscope">
							<header class="entry-header ast-header-without-markup">
							</header>
							<div class="entry-content clear" itemprop="text">
								<div data-elementor-type="wp-page" data-elementor-id="8" class="elementor elementor-8" data-elementor-settings="[]">
									<div class="elementor-inner">
										<div class="elementor-section-wrap">
											<section class="elementor-section elementor-top-section elementor-element elementor-element-7654b20 elementor-section-height-min-height elementor-section-content-bottom elementor-section-items-bottom elementor-section-boxed elementor-section-height-default" data-id="7654b20" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
												<div class="elementor-background-overlay"></div>
												<div class="elementor-container elementor-column-gap-no">
													<div class="elementor-row">
														<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-84ecc6e" data-id="84ecc6e" data-element_type="column">
															<div class="elementor-column-wrap elementor-element-populated">
																<div class="elementor-widget-wrap">
																	<div class="elementor-element elementor-element-5a51642 elementor-widget elementor-widget-heading" data-id="5a51642" data-element_type="widget" data-widget_type="heading.default">
																		<div class="elementor-widget-container">
																			<h6 class="elementor-heading-title elementor-size-default">A few words</h6>
																		</div>
																	</div>
																	<div class="elementor-element elementor-element-6b189d5 elementor-widget elementor-widget-heading" data-id="6b189d5" data-element_type="widget" data-widget_type="heading.default">
																		<div class="elementor-widget-container">
																			<h1 class="elementor-heading-title elementor-size-default">Who we are</h1>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</section>
											<section class="elementor-section elementor-top-section elementor-element elementor-element-add0515 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="add0515" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
												<div class="elementor-container elementor-column-gap-no">
													<div class="elementor-row">
														<div class="elementor-column mt-5 elementor-col-50 elementor-top-column elementor-element elementor-element-2a09f1b" data-id="2a09f1b" data-element_type="column">
															<div class="elementor-column-wrap elementor-element-populated">
																<div class="elementor-widget-wrap">
																	<div class="elementor-element elementor-element-7f8ade2 elementor-widget elementor-widget-heading" data-id="7f8ade2" data-element_type="widget" data-widget_type="heading.default">
																		<div class="elementor-widget-container">
																			<h6 class="elementor-heading-title elementor-size-default"><b>Vision</b></h6>
																		</div>
																	</div>
																	<div class="elementor-element elementor-element-fc89d7c mt-4 elementor-widget elementor-widget-heading" data-id="fc89d7c" data-element_type="widget" data-widget_type="heading.default">
																		<div class="elementor-widget-container">
																			<h6 class="elementor-heading-title mission-vision-font elementor-size-default">We see a global community of well-informed, principled and equipped young leaders with knowledge for personal and societal development to drive Nigeria to it’s peak potential.</h6>
																		</div>
																	</div>
																</div>
															</div>
														</div>
														<div class="elementor-column mt-5 elementor-col-50 elementor-top-column elementor-element elementor-element-2a09f1b" data-id="2a09f1b" data-element_type="column">
															<div class="elementor-column-wrap elementor-element-populated">
																<div class="elementor-widget-wrap">

                                                                    <div class="elementor-element elementor-element-7f8ade2 elementor-widget elementor-widget-heading" data-id="7f8ade2" data-element_type="widget" data-widget_type="heading.default">
                                                                        <div class="elementor-widget-container">
                                                                            <h6 class="elementor-heading-title elementor-size-default"><b>Mission</b></h6>
                                                                        </div>
                                                                    </div>
                                                                    <div class="elementor-element elementor-element-fc89d7c mt-4 elementor-widget elementor-widget-heading" data-id="fc89d7c" data-element_type="widget" data-widget_type="heading.default">
                                                                        <div class="elementor-widget-container">
                                                                            <h6 class="elementor-heading-title mission-vision-font elementor-size-default">To educate, equip and foster the growth of young leaders particularly in marginalized communities by providing the knowledge, research materials and skills necessary for their development.</h6>
                                                                        </div>
                                                                    </div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</section>
											<section class="elementor-section elementor-top-section elementor-element elementor-element-41785d6 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="41785d6" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
												<div class="elementor-background-overlay"></div>
												<div class="elementor-container elementor-column-gap-no">
													<div class="elementor-row">
														<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-afd0996" data-id="afd0996" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
															<div class="elementor-column-wrap elementor-element-populated">
																<div class="elementor-widget-wrap">
																	<div class="elementor-element elementor-element-d84b450 elementor-widget elementor-widget-heading" data-id="d84b450" data-element_type="widget" data-widget_type="heading.default">
																		<div class="elementor-widget-container">
																			<h4 class="elementor-heading-title elementor-size-default text-cap">Services</h4>
																		</div>
																	</div>
																	<div class="elementor-element elementor-element-ec2c859 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="ec2c859" data-element_type="widget" data-widget_type="divider.default">
																		<div class="elementor-widget-container">
																			<div class="elementor-divider">
																				<span class="elementor-divider-separator">
																				</span>
																			</div>
																		</div>
																	</div>
																	<div class="elementor-element elementor-element-adc30d6 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="adc30d6" data-element_type="widget" data-widget_type="icon-list.default">
																		<div class="elementor-widget-container">
																			<ul class="elementor-icon-list-items">
																				<li class="elementor-icon-list-item">
                                                                                    <span class="bullet">&there4;</span> Education
																				</li>
																				<li class="elementor-icon-list-item">
                                                                                    <span class="bullet">&there4;</span> Development trainings/Awareness
																				</li>
																				<li class="elementor-icon-list-item">
                                                                                    <span class="bullet">&there4;</span> Provision of educare materials
																				</li>
																				<li class="elementor-icon-list-item">
                                                                                    <span class="bullet">&there4;</span> Mentorship
																				</li>
																			</ul>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</section>
											<section class="elementor-section elementor-top-section elementor-element elementor-element-2ab0110 elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle" data-id="2ab0110" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
												<div class="elementor-background-overlay"></div>
												<div class="elementor-container elementor-column-gap-no">
													<div class="elementor-row">
														<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-4b9738b" data-id="4b9738b" data-element_type="column">
															<div class="elementor-column-wrap elementor-element-populated">
																<div class="elementor-widget-wrap">
																	<div class="elementor-element elementor-element-2815949 elementor-widget elementor-widget-heading" data-id="2815949" data-element_type="widget" data-widget_type="heading.default">
																		<div class="elementor-widget-container">
																			<h6 class="elementor-heading-title elementor-size-default">Our Values</h6>
																		</div>
																	</div>
																	<div class="elementor-element elementor-element-8c0ad5d elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="8c0ad5d" data-element_type="widget" data-widget_type="divider.default">
																		<div class="elementor-widget-container">
																			<div class="elementor-divider">
																				<span class="elementor-divider-separator">
																				</span>
																			</div>
																		</div>
																	</div>
																	<div class="elementor-element elementor-element-bdcc943 elementor-widget elementor-widget-heading" data-id="bdcc943" data-element_type="widget" data-widget_type="heading.default">
																		<div class="elementor-widget-container">
																			<h3 class="elementor-heading-title elementor-size-default">&mdash; Commitment</h3>
																			<h3 class="elementor-heading-title elementor-size-default">&mdash; Effective communication</h3>
																			<h3 class="elementor-heading-title elementor-size-default">&mdash; Innovation</h3>
																			<h3 class="elementor-heading-title elementor-size-default">&mdash; Measurable impact</h3>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</section>
									</div>
								</div>
							</div>
						</article>
